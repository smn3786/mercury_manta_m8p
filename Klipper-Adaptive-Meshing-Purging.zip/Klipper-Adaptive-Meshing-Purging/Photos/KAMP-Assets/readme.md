Photos used for the GitHub page are kept here.
